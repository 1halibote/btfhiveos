echo "Install depencency for cgminer ->"
echo "*********************************************"
sudo chmod 777 -R ./*
sudo cp ./dep/* /usr/lib/
sudo cp ./dep/libcurl.so.4  /lib/x86_64-linux-gnu/
echo "检查库是否齐全...."
echo "******************************************************"
sudo ldd   /hive/miners/ccminer/tpruvot/2.3.1/ccminer
echo "载入配置文件到CCminer目录"
sudo cp ./cgminer.conf  /hive/miners/ccminer/tpruvot/2.3.1/
echo "*********************************************"
echo "Install depencency for cgminer Done!"
