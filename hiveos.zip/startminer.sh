cd /hive/miners/ccminer/tpruvot/2.3.1/;
sudo ./ccminer -c ./cgminer.conf -a sha256d &